N = 4;            % Number of plots along x axis
M = 4;            % Number of plots along y axis
%BAATARTSOGT ANUJIN
%Group: M3212 
%Date: 09/12/2020
%Teacher: Alexander Meylakhs
%Assignment: Lissajour Curve

for kx = 1:N
    for ky = 1:M

        period = 2*pi/gcd(kx,ky);
        t = linspace(0,period,1000);

        phase = ky*period/4;
        x = sin(kx*t);
        y = sin(ky*t + phase);

        % plot
        subplot(N, M, (kx-1)*M+ky)
        plot(x,y,'-')
        axis equal
        axis([-1.2 1.2 -1.2 1.2])
        title([num2str(kx) ':' num2str(ky)])

        axis off
    end
end
