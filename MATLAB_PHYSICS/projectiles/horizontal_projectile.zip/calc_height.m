function height=calc_height(g,v0,t_flight, theta)
    height = -(g/2)*t_flight^2+v0*sin(pi*(theta/180))*t_flight;
end